package test_01;
import java.util.Scanner;
class div{
	int n,split=0,add=0;
	void splitnum() {
	while(n>0) {
		split=n%10;
		add=add+split;
		n=n/10;
		
	}System.out.println(add);
 }
}
public class Single_Digit {

	public static void main(String[] args) {
		int n;
		Scanner s1=new Scanner(System.in);
		System.out.println("enter the n value");
		n=s1.nextInt();
		if(n>=1 && n<=1000 ) {
			n.splitnum();
	
		}

	}

}
